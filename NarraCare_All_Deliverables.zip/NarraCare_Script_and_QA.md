# NarraCare three minute script


## Slide 1 0:00–0:15

Hello everyone. NarraCare is our rehabilitation recommender. It combines daily exercise recommendations with safety checks and a template-based companion. We focus on how these components work together in a simulated healthcare setting.


## Slide 2 0:15–0:40

The problem is that a rehabilitation plan must respond to changing symptoms and preferences. The same exercise may suit one patient and be inappropriate for another. Our synthetic dataset contains twenty personas, one hundred exercises, and sixty days per rollout, covering knee reconstruction, shoulder repair and chronic back pain.


## Slide 3 0:40–1:20

Each day, the simulator provides patient state. The Safety Agent filters candidates before SAPS ranks them, then checks the shortlist. The Narrator presents the recommendation, and simulated choice and feedback drive the Reward Composer and online updates. SAPS combines LinUCB's reward score with a sampled Beta safety bonus. Feedback about pain change updates that safety estimate for the chosen task. An internal gate also restricts output. Therefore, zero recorded IER reflects the gated system and does not prove that the learner could operate safely without filtering.


## Slide 4 1:20–2:00

In the stored experiment, SAPS achieves mean cumulative reward of forty-six point two nine, compared with forty-one point nine four for LinUCB. Random remains close at forty-five point nine four, which limits claims of broad superiority. The safety ablation provides separate evidence: LinUCB without the Safety Agent produces one hundred and seventy-one violating accepted tasks out of seven hundred and seventy-two. These results describe one synthetic cohort and seed, with shared online learning.


## Slide 5 2:00–2:40

Here is a recorded example from the integrated pipeline. For Alex on day one, safety reduces one hundred candidates to seventy-seven. SAPS proposes standing calf raises, the simulator accepts, and the reward is zero point eight five. The companion displays the narrator's original text. The command-line demo actually runs the five components. This single-file HTML interface replays recorded trajectories offline. Its reply buttons change the presentation while preserving the recorded outcomes, making the system easy to inspect during a demonstration.


## Slide 6 2:40–3:00

Our contribution is a working, inspectable rehabilitation recommendation prototype. The current evidence supports its behavior within the simulator. Next, we need fairer safety measurement, stronger baselines and independent repeated evaluations before making broader claims. Thank you.


# One minute Q&A


## Does zero IER mean SAPS learned to be safe?

No. SAPS's measurement still includes an internal safe-arm gate, so zero IER describes gated output. The NoSafety replay separately supports the value of runtime filtering. We would need an ungated measurement to assess learned safety.


## Why use synthetic patients?

Synthetic personas let us inspect symptoms, choices and rule violations without using identifiable patient records. They support a controlled prototype demonstration. They do not establish clinical benefit or real-world adherence, which require clinical review and appropriate patient evaluation.


## What is new, and how strong is the comparison?

The task-specific contribution combines a LinUCB reward score, Beta pain-feedback signal, safety checks and narrative rendering. The current neural and rule baselines have limitations. We present the reward results as exploratory simulation evidence, with stronger baselines and independent reruns as next steps.