# NarraCare three minute script


## Slide 1 0:00–0:15

Hello everyone. NarraCare is our rehabilitation recommender. It combines daily exercise recommendations with safety checks and a template-based companion. We focus on how these components work together in a simulated healthcare setting.


## Slide 2 0:15–0:40

The problem is that a rehabilitation plan must respond to changing symptoms and preferences. The same exercise may suit one patient and be inappropriate for another. Our synthetic dataset contains twenty personas, one hundred exercises, and sixty days per rollout, covering knee reconstruction, shoulder repair and chronic back pain.


## Slide 3 0:40–1:20

Each day, the simulator provides patient state. Safety filters candidates before SAPS ranks them, then checks the shortlist. The Narrator presents the recommendation, and simulated choice and feedback drive the Reward Composer and online updates. SAPS combines LinUCB's reward score with a sampled Beta safety bonus, updated from the chosen task's pain change. We measure infeasible exploration on an ungated top-five ranking. Infeasible proposals also receive negative updates. Accepted-task violations are logged against all five runtime rules, independently of whether filtering is enabled.


## Slide 4 1:20–2:00

In the repaired experiment, SAPS achieves mean cumulative reward of forty-two point zero two, compared with forty-one point nine four for LinUCB. This difference is small and not statistically significant. Their ungated IER values are zero point zero two two three and zero point zero two three three. Random has higher reward but much higher infeasible exploration. Separately, LinUCB without Safety produces one hundred and seventy-one violating accepted tasks out of seven hundred and seventy-two.


## Slide 5 2:00–2:40

Here is a recorded example from the integrated pipeline. For Alex on day one, safety reduces one hundred candidates to seventy-seven. SAPS proposes standing calf raises, the simulator accepts, and the reward is zero point eight five. The companion displays the narrator's original text. The command-line demo actually runs the five components. This single-file HTML interface replays recorded trajectories offline. Its reply buttons change the presentation while preserving the recorded outcomes, making the system easy to inspect during a demonstration.


## Slide 6 2:40–3:00

Our contribution is a working, inspectable rehabilitation recommendation prototype. The current simulation demonstrates integration and runtime filtering. It does not establish algorithmic superiority or clinical benefit. Next, we need stronger baselines, independent repeated evaluations and separate Beta and penalty ablations. Thank you.


# One minute Q&A


## Is SAPS better than LinUCB?

This experiment does not establish that. SAPS's mean reward advantage is only 0.079, with a paired p-value of 0.743. The IER difference is also not significant. Random has higher reward. Our strongest contribution is inspectable system integration.


## How do you measure safety?

IER evaluates ungated top-five proposals before the output gate. SVR checks accepted tasks against five runtime predicates. Removing Safety gives 171 violations in 772 accepted tasks. These are implemented-rule measurements in a simulator, not a clinical safety guarantee.


## Why use synthetic patients?

Synthetic personas let us inspect symptoms, choices and violations without using identifiable records. They support a controlled prototype demonstration. They do not establish clinical benefit or real-world adherence, which require clinical review and appropriate patient evaluation.