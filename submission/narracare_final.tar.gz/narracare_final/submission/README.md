# Final submission package

- NarraCare_Final_Report.docx: final report; export the formal PDF locally with
  Arial and check 8–12 pages including references.
- verification.md and evidence/: recorded engineering and experiment checks.
- ../SUBMISSION_MANIFEST.json: source commit and SHA256 of every packaged file.

Install requirements from the root README. The live agent needs a provider key
and network; the benchmark CLI and reproduction are offline after installation.
Old versions are excluded; see ../archive/README.md for the GitHub history link.
