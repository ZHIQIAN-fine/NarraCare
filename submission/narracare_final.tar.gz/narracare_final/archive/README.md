# Historical versions

Historical bundles and runners are deliberately excluded from this final-source
package. View the versioned archive at:
https://github.com/ZHIQIAN-fine/NarraCare/tree/7a72b89ff2159d89efa4851c49ea6c1b8554a224/archive

The package contains only the current source, inputs, final evidence, tests,
report and demo. Follow ../README.md for execution.
