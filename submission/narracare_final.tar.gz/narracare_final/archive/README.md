# Historical versions

Historical bundles and runners are deliberately excluded from this final-source
package. View the versioned archive at:
https://github.com/ZHIQIAN-fine/NarraCare/tree/66fc8fede1ca547c26d1ae938c42512ba106c735/archive

The package contains only the current source, inputs, final evidence, tests,
report and demo. Follow ../README.md for execution.
