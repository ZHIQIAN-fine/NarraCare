# Historical versions

Historical bundles and runners are deliberately excluded from this final-source
package. View the versioned archive at:
https://github.com/ZHIQIAN-fine/NarraCare/tree/82e8a805f526e89e81b6e89bff30e9a90f0408b7/archive

The package contains only the current source, inputs, final evidence, tests,
report and demo. Follow ../README.md for execution.
