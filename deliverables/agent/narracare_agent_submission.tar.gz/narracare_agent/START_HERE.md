# NarraCare agent submission

This archive contains current agent source, the unchanged seven-policy synthetic
benchmark, committed artifacts, and the updated report, deck and speaking notes
under `submission/`. It is a coursework prototype, not a clinical service.

## Live interactive demonstration

Use Python 3.10 or newer in an isolated environment. Run from this folder:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt -r requirements-agent.txt
python -m narracare.agent_app --port 7860
```

Before the last command, set `OPENAI_API_KEY` or `NARRACARE_LLM_API_KEY` securely
in the environment. No credential is bundled. Default model: `gpt-4o-mini`.
The live agent requires provider access and network. Open the URL printed by
Gradio locally. Windows activation: `.venv\Scripts\Activate.ps1`.

Terminal alternative: `python -m narracare.agent --user U001 --seed 42`.
Use synthetic inputs only: messages and session context reach the provider.

Suggested separate messages:

1. Hello Pip. Could you recommend a manageable exercise?
2. My pain is 3, fatigue 2, mood 7 and ROM 110. I prefer flexibility.
3. Why did you choose this task?
4. I prefer balance instead; avoid flexibility.
5. I'll try the proposed task. What feedback do you need?
6. Completed. After pain 3, fatigue 3, satisfaction 0.8.
7. Skip today and rest.

Preference changes affect retrieval and the task. Intention creates no reward.
Explicit reported feedback updates the model and trail. Camp creates no invented
outcome. Narrative day and clinical stage remain distinct.

## Offline alternatives and verification

```bash
python -m narracare.demo --user U001 --days 60 --policy saps --seed 42
python -m narracare.demo --inspect
python -m pip install pytest
python -m pytest -q
```

Open `demo/index.html` for an offline recorded replay. Its replies change
presentation only; do not label it live learning. The live agent never silently
falls back to this replay. `python -m narracare.agent_check` performs an optional
real-provider smoke check and incurs provider usage.

See `README.md`, `docs/conversational_agent.md` and `docs/versions.md` for the
architecture, settings and benchmark reproduction scope. Experiment scripts
intentionally regenerate result files: use a disposable extraction to run them.
`SUBMISSION_MANIFEST.json` identifies exact source and protected-file checksums.
The agent/demo entry points do not overwrite the committed benchmark artifacts.
